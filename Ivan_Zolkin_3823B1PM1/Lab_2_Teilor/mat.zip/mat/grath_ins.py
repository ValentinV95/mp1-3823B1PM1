import matplotlib.pyplot as plt
from math import *
inp = open("res","r")
x=[]
y=[]
y2 = []
y3 = []
i = 0
for line in inp:
    i+=1
    n, r, *t = line.split()
    if(i < 16750):
        continue
    if(i> 23350):
        break
    if(n != "exp"):
        continue
    x.append(float(r))
    #e = sin(float(r))
    e1 = t[0]
    if(e1 == '-nan(ind)'):
        y.append(14555555555)
    else:
        y.append(float(e1))
    #e = sin(float(r))
    e1=t[1]
    if(e1 == '-nan(ind)'):
        y2.append(14555555555)
    else:
        y2.append(float(e1))
    #e = sin(float(r))
    e1=t[2];
    if(e1 == '-nan(ind)'):
        y3.append(14555555555)
    else:
        y3.append(float(e1))
          

print(len(x),len(y),len(y2),len(y3))
plt.figure(figsize=(8, 6))
print(x,y)



# График для y
plt.plot(x, y, marker='o', linestyle='-', label='прямой', color='blue')
# График для y3
plt.plot(x, y3, marker='o', linestyle='-', label='парный(прямой)', color='green')


# График для y2
plt.plot(x, y2, marker='o', linestyle='-', label='обратный', color='red')


plt.title('График ошибок от х')
plt.xlabel('x')
plt.ylabel('Ошибка')
plt.grid(True)
plt.legend()
plt.show()