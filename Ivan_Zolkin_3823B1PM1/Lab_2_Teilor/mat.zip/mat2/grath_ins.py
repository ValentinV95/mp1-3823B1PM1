import matplotlib.pyplot as plt
from math import *
import struct
inp = open("res","rb")
x=[]
y=[]
y2 = []
y3 = []
i = 0
ran = int(float(struct.unpack('<f', inp.read(4))[0])+0.01)
print(ran)
for i in range(ran):
    for j in range(4):  #sin-log-cos-exp
        data = []
        if(j!=3):
            struct.unpack('<f',inp.read(4))[0]
            struct.unpack('<f',inp.read(4))[0]
            struct.unpack('<f',inp.read(4))[0]
            struct.unpack('<f',inp.read(4))[0]
            continue
        for u in range(4): #x for back pair
            data.append(float(struct.unpack('<f',inp.read(4))[0]))
        
        
        #----------------------------
        if(i>ran/2-4500 and i<ran/2+4500):
            x.append(round(data[0],2))
            #e = sin(float(r))
            e1 = data[1]
            if(str(e1)=='nan'):
                y.append(1450000000)
            else:
                y.append(float(e1))
            #e = sin(float(r))
            e1=data[1]
            if(str(e1)=='nan'):
                y2.append(1450000000)
            else:
                y2.append(float(e1))
            #e = sin(float(r))
            e1=data[2];
            if(str(e1)=='nan'):
                y3.append(1450000000)
            else:
                y3.append(float(e1))
        #-----------------------------

plt.figure(figsize=(8, 6))



# График для y
plt.plot(x, y, marker='o', linestyle='-', label='прямой',color='blue')


# График для y2
plt.plot(x, y2, marker='o', linestyle='-', label='обратный', color='red')

# График для y3
plt.plot(x, y3, marker='o', linestyle='-', label='парный(прямой)', color='green')


plt.title('График ошибок от х')
plt.xlabel('x')
plt.ylabel('Ошибка')
plt.grid(True)
plt.legend()
plt.show()